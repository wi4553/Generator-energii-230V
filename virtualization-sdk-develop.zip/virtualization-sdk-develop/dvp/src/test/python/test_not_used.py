#
# Copyright (c) 2019 by Delphix. All rights reserved.
#


def test_not_used():
    """
    The build will fail if there are no tests. This is an empty package needed
    to tie together the other dvp packages so there's nothing to test.
    """

