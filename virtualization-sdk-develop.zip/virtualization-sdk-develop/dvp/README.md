The Delphix Virtualization SDK helps developers build plugins to ingest and provision data on top of the Delphix platform. For more information please refer to the [documentation](https://developer.delphix.com/).

# Getting Started

Please refer to the [Getting Started](https://developer.delphix.com/Getting_Started/) section of the documentation.

# Disclaimer

The software is provided “as-is” without any warranties of any kind. To the maximum extent permitted by applicable law, Delphix Corp. and its affiliates disclaim any liability, implied warranties, including, without limitation, any implied warranties of merchantability, fitness for a particular purpose and non-infringement of intellectual property rights.