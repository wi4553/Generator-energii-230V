#
# Copyright (c) 2019, 2021 by Delphix. All rights reserved.
#

"""
This module is mimicking what happens on the Delphix Engine to support testing
internal wrappers.
"""


def run_bash(run_bash_request):
    pass


def run_sync(run_sync_request):
    pass


def run_powershell(run_powershell_request):
    pass


def run_expect(run_expect_request):
    pass


def log(log_debug_request):
    pass
