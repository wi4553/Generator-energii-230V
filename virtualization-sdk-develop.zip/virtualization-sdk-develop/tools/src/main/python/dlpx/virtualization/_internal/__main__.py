#
# Copyright (c) 2019 by Delphix. All rights reserved.
#

from dlpx.virtualization._internal import cli


def main():
    cli.delphix_sdk()


if __name__ == '__main__':
    main()
